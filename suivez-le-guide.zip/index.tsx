import "https://unpkg.com/leaflet@1.9.4/dist/leaflet.js";
import "https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js";

declare const L: any;
declare const JSZip: any;

interface PoiData {
    id: number;
    lat: number;
    lon: number;
    title: string;
    comment: string;
    folder: string;
    image?: string;
    audio?: string;
    video?: string;
}

interface PoiWithMarker {
    poi: PoiData;
    marker: any;
}

class TourGuideApp {
    private map: any;
    private poiAndMarkers: PoiWithMarker[] = [];
    private poiListContainer: HTMLElement | null;
    private poiListElement: HTMLElement | null;
    private poiListItems: Map<number, HTMLElement> = new Map();
    private userLocationMarker: any = null;
    private currentUserLocation: GeolocationCoordinates | null = null;
    private locationWatchId: number | null = null;
    private activePoiForLocation: PoiData | null = null;
    private hasCenteredOnUser = false;


    constructor() {
        this.poiListContainer = document.getElementById('poi-list-container');
        this.poiListElement = document.getElementById('poi-list');
        this.initMap();
        this.initUI();
        this.initGeolocation();
    }

    private initMap(): void {
        this.map = L.map('map').setView([46.603354, 1.888334], 6);

        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        }).addTo(this.map);
    }

    private initUI(): void {
        const loadButton = document.getElementById('load-zip-button');
        const fileInput = document.getElementById('zip-input') as HTMLInputElement;

        if (loadButton && fileInput) {
            loadButton.addEventListener('click', () => fileInput.click());
            fileInput.addEventListener('change', this.handleFileSelect.bind(this));
        }
    }

    private initGeolocation(): void {
        if ('geolocation' in navigator) {
            this.locationWatchId = navigator.geolocation.watchPosition(
                this.handleLocationSuccess.bind(this),
                this.handleLocationError.bind(this),
                { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
            );
        } else {
            alert("La géolocalisation n'est pas supportée par votre navigateur.");
        }
    }

    private handleLocationSuccess(position: GeolocationPosition): void {
        this.currentUserLocation = position.coords;
        const { latitude, longitude } = position.coords;

        if (!this.userLocationMarker) {
            const userIcon = L.divIcon({
                className: 'user-location-marker',
                html: '<div></div>',
                iconSize: [24, 24],
            });
            this.userLocationMarker = L.marker([latitude, longitude], { icon: userIcon })
                .addTo(this.map)
                .bindTooltip("Votre position", { permanent: false, direction: 'top' });
        } else {
            this.userLocationMarker.setLatLng([latitude, longitude]);
        }

        if (!this.hasCenteredOnUser) {
            this.map.setView([latitude, longitude], 15);
            this.hasCenteredOnUser = true;
        }

        this.updateLocationInfoInPopup();
    }

    private handleLocationError(error: GeolocationPositionError): void {
        let message = "Impossible d'obtenir votre position. ";
        switch (error.code) {
            case error.PERMISSION_DENIED:
                message += "Vous avez refusé la demande de géolocalisation.";
                break;
            case error.POSITION_UNAVAILABLE:
                message += "Les informations de localisation sont indisponibles.";
                break;
            case error.TIMEOUT:
                message += "La demande de localisation a expiré.";
                break;
            default:
                message += "Une erreur inconnue est survenue.";
                break;
        }
        alert(message);
    }
    
    private showLoader(show: boolean): void {
        const loader = document.getElementById('loader');
        if (loader) {
            loader.style.display = show ? 'block' : 'none';
        }
    }

    private clearMap(): void {
        this.poiAndMarkers.forEach(({ marker }) => this.map.removeLayer(marker));
        this.poiAndMarkers = [];
        if (this.poiListElement) {
            this.poiListElement.innerHTML = '';
        }
        this.poiListItems.clear();
        if (this.poiListContainer) {
            this.poiListContainer.classList.add('hidden');
        }
        this.hasCenteredOnUser = false; // Reset centering for next tour
    }

    private async handleFileSelect(event: Event): Promise<void> {
        const input = event.target as HTMLInputElement;
        if (!input.files || input.files.length === 0) {
            return;
        }

        const file = input.files[0];
        this.showLoader(true);
        this.clearMap();

        try {
            const zip = await JSZip.loadAsync(file);
            const visitJsonFile = zip.file("visit.json");

            if (!visitJsonFile) {
                throw new Error("Le fichier 'visit.json' est introuvable à la racine du fichier ZIP.");
            }
            
            const visitData = JSON.parse(await visitJsonFile.async("string"));
            const poiDataPromises = visitData.map((poiInfo: any) => this.processPoi(zip, poiInfo));
            const allPoiData = await Promise.all(poiDataPromises);
            const validPois = allPoiData.filter((p): p is PoiData => p !== null);

            if (validPois.length > 0) {
                const markerGroup = L.featureGroup();
                validPois.forEach(poi => {
                    const initialContent = `<h3>${poi.title}</h3><p>${poi.comment}</p><div class="media-loader">Chargement du média...</div>`;
                    const popup = L.popup({ maxWidth: 400, minWidth: 300 }).setContent(initialContent);

                    const marker = L.marker([poi.lat, poi.lon]).bindPopup(popup);
                    
                    marker.on('popupopen', async (e: any) => {
                        this.setActivePoi(poi.id);
                        this.activePoiForLocation = poi;
                        const fullContentElement = await this.createPopupContent(zip, poi, e.target);
                        e.popup.setContent(fullContentElement).update();
                        this.updateLocationInfoInPopup();
                    });

                    marker.on('popupclose', () => {
                        this.setActivePoi(null);
                        this.activePoiForLocation = null;
                    });
                    
                    this.poiAndMarkers.push({ poi, marker });
                    markerGroup.addLayer(marker);
                });
                
                markerGroup.addTo(this.map);
                if (!this.hasCenteredOnUser) {
                  this.map.fitBounds(markerGroup.getBounds().pad(0.1));
                }
                this.renderPoiList();

            } else {
                 alert("Aucun point d'intérêt valide n'a pu être chargé à partir de visit.json.");
            }

        } catch (error) {
            console.error("Erreur lors du traitement du fichier ZIP:", error);
            alert(`Erreur lors de la lecture du fichier ZIP: ${error.message}`);
        } finally {
            this.showLoader(false);
            input.value = '';
        }
    }

    private setActivePoi(poiId: number | null): void {
        this.poiListItems.forEach((item, id) => {
            if (id === poiId) {
                item.classList.add('active');
                item.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
            } else {
                item.classList.remove('active');
            }
        });
    }

    private renderPoiList(): void {
        if (!this.poiListElement || !this.poiListContainer) return;
        
        this.poiListElement.innerHTML = '';
        this.poiListItems.clear();

        this.poiAndMarkers
            .sort((a, b) => a.poi.id - b.poi.id)
            .forEach(({ poi, marker }) => {
                const listItem = document.createElement('li');
                listItem.textContent = poi.title;
                listItem.setAttribute('role', 'button');
                listItem.setAttribute('tabindex', '0');
                
                this.poiListItems.set(poi.id, listItem);

                listItem.addEventListener('click', () => {
                    this.map.flyTo([poi.lat, poi.lon], 16);
                    marker.openPopup();
                });
                listItem.addEventListener('keydown', (e) => {
                  if (e.key === 'Enter' || e.key === ' ') {
                    this.map.flyTo([poi.lat, poi.lon], 16);
                    marker.openPopup();
                  }
                });
                this.poiListElement.appendChild(listItem);
        });

        this.poiListContainer.classList.remove('hidden');
    }
    
    private parseCoordinate(coordString: string): number {
        const coord = coordString.trim().toUpperCase();
        const lastChar = coord.slice(-1);
    
        if (['N', 'S', 'E', 'W'].includes(lastChar)) {
            const valueStr = coord.slice(0, -1);
            let value = parseFloat(valueStr);
    
            if (isNaN(value)) return NaN;
            
            if (lastChar === 'S' || lastChar === 'W') {
                value *= -1;
            }
            return value;
        } else {
            const value = parseFloat(coord);
            return isNaN(value) ? NaN : value;
        }
    }

    private async processPoi(zip: any, poiInfo: any): Promise<PoiData | null> {
        if (!poiInfo.folder || !poiInfo.titleFile || !poiInfo.locationFile || !poiInfo.commentFile) {
            console.warn(`Entrée invalide dans visit.json ignorée: ${JSON.stringify(poiInfo)}`);
            return null;
        }

        const folderPath = `data/${poiInfo.folder}/`;
        const titleFile = zip.file(`${folderPath}${poiInfo.titleFile}`);
        const locFile = zip.file(`${folderPath}${poiInfo.locationFile}`);
        const commentFile = zip.file(`${folderPath}${poiInfo.commentFile}`);

        if (!titleFile || !locFile || !commentFile) {
            console.warn(`Fichiers de base manquants pour le point d'intérêt dans ${folderPath}`);
            return null;
        }

        try {
            const title = await titleFile.async("string");
            const locString = await locFile.async("string");
            const comment = await commentFile.async("string");

            const [latStr, lonStr] = locString.split(',').map(s => s.trim());
            const lat = this.parseCoordinate(latStr);
            const lon = this.parseCoordinate(lonStr);

            if (isNaN(lat) || isNaN(lon)) {
                 console.warn(`Coordonnées invalides dans ${folderPath}${poiInfo.locationFile}: ${locString}`);
                 return null;
            }

            return { 
                id: poiInfo.id,
                lat, 
                lon, 
                title, 
                comment: comment.replace(/\n/g, '<br>'),
                folder: poiInfo.folder,
                image: poiInfo.image,
                audio: poiInfo.audio,
                video: poiInfo.video,
            };
        } catch (e) {
            console.error(`Erreur lors de la lecture des fichiers pour le POI dans ${folderPath}`, e);
            return null;
        }
    }

    private async createPopupContent(zip: any, poi: PoiData, marker: any): Promise<HTMLElement> {
        const container = document.createElement('div');

        const title = document.createElement('h3');
        title.textContent = poi.title;
        container.appendChild(title);

        const comment = document.createElement('p');
        comment.innerHTML = poi.comment;
        container.appendChild(comment);

        const getMediaAsObjectUrl = async (path: string): Promise<string | null> => {
            const file = zip.file(path);
            if (!file) {
                console.error(`Media file not found in ZIP: ${path}`);
                return null;
            }
            try {
                const blob = await file.async("blob");
                return URL.createObjectURL(blob);
            } catch (e) {
                console.error(`Could not load media file: ${path}`, e);
                return null;
            }
        };

        const createMediaErrorElement = (message: string): HTMLElement => {
            const errorP = document.createElement('p');
            errorP.className = 'media-error';
            errorP.textContent = message;
            return errorP;
        };
        
        const mediaContainer = document.createElement('div');
        mediaContainer.className = 'popup-media-container';
        let hasMedia = false;
        const objectUrlsToRevoke: string[] = [];
        const mediaElements: (HTMLAudioElement | HTMLVideoElement)[] = [];

        if (poi.audio) {
            const audioUrl = await getMediaAsObjectUrl(`data/${poi.folder}/${poi.audio}`);
            if (audioUrl) {
                const audio = document.createElement('audio');
                audio.controls = true;
                audio.autoplay = true;
                audio.src = audioUrl;
                audio.className = 'popup-media';
                audio.textContent = 'Votre navigateur ne supporte pas l\'élément audio.';
                audio.addEventListener('error', () => {
                    const errorMsg = (audio.error?.code === 4) 
                      ? `Erreur : Format audio non supporté ou fichier '${poi.audio}' corrompu.`
                      : `Erreur de lecture du fichier audio '${poi.audio}'.`;
                    if (audio.parentElement) {
                       audio.parentElement.replaceChild(createMediaErrorElement(errorMsg), audio);
                    }
                });
                mediaContainer.appendChild(audio);
                hasMedia = true;
                objectUrlsToRevoke.push(audioUrl);
                mediaElements.push(audio);
            } else {
                 mediaContainer.appendChild(createMediaErrorElement(`Erreur : Fichier audio '${poi.audio}' introuvable.`));
                 hasMedia = true;
            }
        }
        if (poi.image) {
            const imageUrl = await getMediaAsObjectUrl(`data/${poi.folder}/${poi.image}`);
            if (imageUrl) {
                const img = document.createElement('img');
                img.src = imageUrl;
                img.alt = poi.title;
                img.className = 'popup-media';
                img.addEventListener('error', () => {
                     if (img.parentElement) {
                        img.parentElement.replaceChild(createMediaErrorElement(`Erreur : Impossible d'afficher l'image '${poi.image}'.`), img);
                    }
                });
                mediaContainer.appendChild(img);
                hasMedia = true;
                objectUrlsToRevoke.push(imageUrl);
            } else {
                mediaContainer.appendChild(createMediaErrorElement(`Erreur : Image '${poi.image}' introuvable.`));
                hasMedia = true;
            }
        }
        if (poi.video) {
            const videoUrl = await getMediaAsObjectUrl(`data/${poi.folder}/${poi.video}`);
            if (videoUrl) {
                const video = document.createElement('video');
                video.controls = true;
                video.src = videoUrl;
                video.className = 'popup-media';
                video.textContent = 'Votre navigateur ne supporte pas l\'élément vidéo.';
                video.addEventListener('error', () => {
                    const errorMsg = (video.error?.code === 4) 
                      ? `Erreur : Format vidéo non supporté ou fichier '${poi.video}' corrompu.`
                      : `Erreur de lecture du fichier vidéo '${poi.video}'.`;
                    if (video.parentElement) {
                        video.parentElement.replaceChild(createMediaErrorElement(errorMsg), video);
                    }
                });
                mediaContainer.appendChild(video);
                hasMedia = true;
                objectUrlsToRevoke.push(videoUrl);
                mediaElements.push(video);
            } else {
                mediaContainer.appendChild(createMediaErrorElement(`Erreur : Fichier vidéo '${poi.video}' introuvable.`));
                hasMedia = true;
            }
        }

        if (hasMedia) {
            container.appendChild(mediaContainer);
        }
        
        const locationInfo = document.createElement('div');
        locationInfo.className = 'poi-location-info';
        locationInfo.id = `poi-location-info-${poi.id}`;
        container.appendChild(locationInfo);
        
        if (marker) {
            marker.once('popupclose', () => {
                mediaElements.forEach(media => {
                    media.pause();
                    media.currentTime = 0;
                });
                objectUrlsToRevoke.forEach(url => URL.revokeObjectURL(url));
            });
        }
        
        return container;
    }

    private updateLocationInfoInPopup(): void {
        if (!this.activePoiForLocation || !this.currentUserLocation) return;
    
        const poi = this.activePoiForLocation;
        const infoElement = document.getElementById(`poi-location-info-${poi.id}`);
        
        if (infoElement) {
            const distance = this.calculateDistance(
                this.currentUserLocation.latitude, this.currentUserLocation.longitude,
                poi.lat, poi.lon
            );
            const bearing = this.calculateBearing(
                this.currentUserLocation.latitude, this.currentUserLocation.longitude,
                poi.lat, poi.lon
            );
    
            infoElement.innerHTML = `
                <p><strong>Distance :</strong> ${distance.toFixed(0)} mètres</p>
                <p><strong>Azimut :</strong> ${bearing.toFixed(0)}° Nord</p>
            `;
        }
    }
    
    private calculateDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
        const R = 6371e3; // Rayon de la Terre en mètres
        const φ1 = lat1 * Math.PI / 180;
        const φ2 = lat2 * Math.PI / 180;
        const Δφ = (lat2 - lat1) * Math.PI / 180;
        const Δλ = (lon2 - lon1) * Math.PI / 180;
    
        const a = Math.sin(Δφ / 2) * Math.sin(Δφ / 2) +
                  Math.cos(φ1) * Math.cos(φ2) *
                  Math.sin(Δλ / 2) * Math.sin(Δλ / 2);
        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    
        return R * c; // en mètres
    }
    
    private calculateBearing(lat1: number, lon1: number, lat2: number, lon2: number): number {
        const φ1 = lat1 * Math.PI / 180;
        const φ2 = lat2 * Math.PI / 180;
        const λ1 = lon1 * Math.PI / 180;
        const λ2 = lon2 * Math.PI / 180;
    
        const y = Math.sin(λ2 - λ1) * Math.cos(φ2);
        const x = Math.cos(φ1) * Math.sin(φ2) -
                  Math.sin(φ1) * Math.cos(φ2) * Math.cos(λ2 - λ1);
        const θ = Math.atan2(y, x);
    
        return (θ * 180 / Math.PI + 360) % 360; // en degrés
    }
}

new TourGuideApp();
